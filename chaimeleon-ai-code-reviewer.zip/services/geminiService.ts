import { GoogleGenAI, Type } from "@google/genai";
import { IssueCategory, IssueSeverity, ReviewResult } from '../types';

// FIX: Initialize GoogleGenAI with API_KEY from environment variables and remove hardcoded key
// as per the coding guidelines.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    overallAssessment: {
      type: Type.STRING,
      description: "A high-level summary of the code quality, highlighting key strengths and areas for improvement from a Machine Learning perspective."
    },
    issues: {
      type: Type.ARRAY,
      description: "A list of identified issues in the code.",
      items: {
        type: Type.OBJECT,
        properties: {
          id: {
            type: Type.STRING,
            description: "A unique identifier for the issue, e.g., 'REP-001'."
          },
          category: {
            type: Type.STRING,
            enum: Object.values(IssueCategory),
            description: "The category of the issue."
          },
          severity: {
            type: Type.STRING,
            enum: Object.values(IssueSeverity),
            description: "The severity level of the issue."
          },
          summary: {
            type: Type.STRING,
            description: "A concise summary of the issue."
          },
          recommendation: {
            type: Type.STRING,
            description: "An actionable recommendation on how to fix the issue, including code examples where possible."
          }
        },
        required: ["id", "category", "severity", "summary", "recommendation"]
      }
    }
  },
  required: ["overallAssessment", "issues"]
};

export const analyzeCode = async (code: string): Promise<ReviewResult> => {
  // FIX: Removed the API key check as per coding guidelines. The API key is
  // expected to be configured in the environment.
  
  const prompt = `
    As an expert Machine Learning engineer and senior software developer, please perform a thorough code review of the following Python script. 
    
    Focus on common pitfalls in data science and machine learning code. Specifically, analyze the following aspects:
    1.  **Reproducibility**: Check for missing random seeds in model initialization and data splitting (e.g., train_test_split).
    2.  **Best Practices**: Look for hardcoded paths, magic numbers, use of 'print' instead of logging, and unclear function names or missing docstrings.
    3.  **Data Science**: Identify potential data leakage, inefficient use of libraries like Pandas or NumPy, and improper model evaluation techniques.
    4.  **MLOps**: Assess if the code is suitable for production. Is it modular? Are there clear inputs and outputs? Is it easily testable?
    5.  **Performance**: Note any obvious performance bottlenecks or inefficient computations.

    Provide an overall assessment and a list of specific, actionable recommendations for each issue you find.

    Code to analyze:
    \`\`\`python
    ${code}
    \`\`\`
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
      },
    });

    const jsonText = response.text.trim();
    if (!jsonText) {
      throw new Error("API returned an empty response.");
    }

    const parsedResult = JSON.parse(jsonText);

    // Validate the parsed structure
    if (!parsedResult.overallAssessment || !Array.isArray(parsedResult.issues)) {
      throw new Error("Invalid response structure from API.");
    }
    
    return parsedResult as ReviewResult;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get analysis from AI. Please check the console for more details.");
  }
};

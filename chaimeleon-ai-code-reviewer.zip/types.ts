export enum IssueCategory {
  SECURITY = 'Security',
  PERFORMANCE = 'Performance',
  BEST_PRACTICES = 'Best Practices',
  READABILITY = 'Readability',
  REPRODUCIBILITY = 'Reproducibility',
  DATA_SCIENCE = 'Data Science',
  MLOPS = 'MLOps',
  BUGS = 'Potential Bugs',
  OTHER = 'Other'
}

export enum IssueSeverity {
  CRITICAL = 'Critical',
  HIGH = 'High',
  MEDIUM = 'Medium',
  LOW = 'Low'
}

export interface ReviewIssue {
  id: string;
  category: IssueCategory;
  severity: IssueSeverity;
  summary: string;
  recommendation: string;
}

export interface ReviewResult {
  overallAssessment: string;
  issues: ReviewIssue[];
}
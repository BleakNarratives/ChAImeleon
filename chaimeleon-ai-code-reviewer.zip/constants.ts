export const sampleCode = `import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# Load data from a hardcoded path
data = pd.read_csv("/path/to/your/dataset.csv")

# Assume last column is the target
X = data.iloc[:, :-1]
y = data.iloc[:, -1]

# Splitting data without a random_state for reproducibility
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Using a model without a fixed random_state
model = RandomForestClassifier(n_estimators=100)
model.fit(X_train, y_train)

predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)

# Using print instead of a proper logging framework
print(f"Model Accuracy: {accuracy}")

def get_feature_importance(model, features):
    # This is a poorly named function and lacks docstrings
    importances = model.feature_importances_
    feature_importance_df = pd.DataFrame({
        'feature': features.columns,
        'importance': importances
    })
    return feature_importance_df.sort_values(by='importance', ascending=False)

# The function is called but its result is not used or stored
get_feature_importance(model, X_train)
`;

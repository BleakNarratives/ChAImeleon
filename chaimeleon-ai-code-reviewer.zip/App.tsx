
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { CodeInput } from './components/CodeInput';
import { ReviewResults } from './components/ReviewResults';
import { Footer } from './components/Footer';
import { analyzeCode } from './services/geminiService';
import { ReviewResult } from './types';
import { sampleCode } from './constants';

const App: React.FC = () => {
  const [code, setCode] = useState<string>(sampleCode);
  const [reviewResult, setReviewResult] = useState<ReviewResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyzeClick = useCallback(async () => {
    if (!code.trim()) {
      setError('Please enter some code to analyze.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setReviewResult(null);
    try {
      const result = await analyzeCode(code);
      setReviewResult(result);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unexpected error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [code]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 flex flex-col font-sans">
      <Header />
      <main className="flex-grow container mx-auto p-4 md:p-6 lg:p-8 flex flex-col lg:flex-row gap-6 lg:gap-8">
        <div className="lg:w-1/2 flex flex-col h-[calc(100vh-220px)] md:h-[calc(100vh-200px)]">
          <CodeInput
            code={code}
            setCode={setCode}
            onAnalyze={handleAnalyzeClick}
            isLoading={isLoading}
          />
        </div>
        <div className="lg:w-1/2 flex flex-col h-[calc(100vh-220px)] md:h-[calc(100vh-200px)]">
          <ReviewResults
            reviewResult={reviewResult}
            isLoading={isLoading}
            error={error}
          />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;

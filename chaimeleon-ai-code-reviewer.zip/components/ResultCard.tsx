
import React from 'react';
import { ReviewIssue, IssueSeverity } from '../types';

interface ResultCardProps {
  issue: ReviewIssue;
}

const severityConfig = {
    [IssueSeverity.CRITICAL]: {
        bgColor: 'bg-red-900/50',
        borderColor: 'border-red-700',
        textColor: 'text-red-300',
    },
    [IssueSeverity.HIGH]: {
        bgColor: 'bg-orange-900/50',
        borderColor: 'border-orange-700',
        textColor: 'text-orange-300',
    },
    [IssueSeverity.MEDIUM]: {
        bgColor: 'bg-yellow-900/50',
        borderColor: 'border-yellow-700',
        textColor: 'text-yellow-300',
    },
    [IssueSeverity.LOW]: {
        bgColor: 'bg-blue-900/50',
        borderColor: 'border-blue-700',
        textColor: 'text-blue-300',
    },
};

export const ResultCard: React.FC<ResultCardProps> = ({ issue }) => {
  const config = severityConfig[issue.severity] || severityConfig[IssueSeverity.LOW];

  return (
    <div className={`border-l-4 ${config.borderColor} ${config.bgColor} p-4 rounded-r-lg shadow-md`}>
      <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-2">
        <h4 className="text-lg font-bold text-gray-100">{issue.summary}</h4>
        <div className="flex items-center mt-2 sm:mt-0">
          <span className={`px-3 py-1 text-xs font-semibold rounded-full ${config.bgColor} ${config.textColor} border ${config.borderColor} mr-3`}>
            {issue.severity.toUpperCase()}
          </span>
          <span className="px-3 py-1 text-xs font-semibold text-gray-300 bg-gray-700 rounded-full">
            {issue.category}
          </span>
        </div>
      </div>
      <div className="prose prose-sm prose-invert max-w-none text-gray-300">
        <p className="font-semibold text-gray-200 mt-3">Recommendation:</p>
        <pre className="bg-gray-900/70 p-3 rounded-md overflow-x-auto custom-scrollbar">
            <code>{issue.recommendation}</code>
        </pre>
      </div>
    </div>
  );
};

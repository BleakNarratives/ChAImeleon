
import React from 'react';
import { Spinner } from './Spinner';

interface CodeInputProps {
  code: string;
  setCode: (code: string) => void;
  onAnalyze: () => void;
  isLoading: boolean;
}

export const CodeInput: React.FC<CodeInputProps> = ({ code, setCode, onAnalyze, isLoading }) => {
  return (
    <div className="bg-gray-800 rounded-lg shadow-xl flex flex-col h-full border border-gray-700">
      <div className="flex justify-between items-center p-3 border-b border-gray-700">
        <h2 className="text-lg font-semibold text-gray-200">Code Input</h2>
        <button
          onClick={onAnalyze}
          disabled={isLoading}
          className="flex items-center justify-center px-4 py-2 bg-green-600 text-white font-semibold rounded-md hover:bg-green-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-opacity-75"
        >
          {isLoading ? (
            <>
              <Spinner />
              Analyzing...
            </>
          ) : (
            'Analyze Code'
          )}
        </button>
      </div>
      <div className="flex-grow p-1">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="Paste your code here..."
          className="w-full h-full p-3 bg-gray-900 text-gray-300 font-mono text-sm resize-none rounded-b-md focus:outline-none focus:ring-2 focus:ring-inset focus:ring-green-500"
          spellCheck="false"
        />
      </div>
    </div>
  );
};

import React from 'react';

const ChameleonIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-400 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m21.5 7.5-8.3 8.3c-.9.9-2.2 1.2-3.5 1-1.3-.3-2.5-1-3.2-2.2s-.9-2.6-.5-3.9c.4-1.3 1.3-2.4 2.5-3l8-8"/>
      <path d="m16 5 3 3"/>
      <path d="M8.5 12.5a2.5 2.5 0 1 0-5 0 2.5 2.5 0 0 0 5 0Z"/>
      <path d="M14 17.5c-1.5 1.5-3 2-4.5 2s-3-1.5-4.5-2"/>
    </svg>
  );

export const Header: React.FC = () => {
  return (
    <header className="bg-gray-800/50 backdrop-blur-sm border-b border-gray-700 shadow-lg sticky top-0 z-10">
      <div className="container mx-auto px-4 md:px-6 py-4 flex items-center justify-between">
        <div className="flex items-center">
            <ChameleonIcon />
            <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight">
            Ch<span className="text-green-400">AI</span>meleon
            </h1>
        </div>
        <p className="hidden md:block text-gray-400">AI-Powered ML Code Review Assistant</p>
      </div>
    </header>
  );
};

import React from 'react';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="bg-gray-800/50 border-t border-gray-700 mt-auto">
      <div className="container mx-auto px-4 md:px-6 py-4 text-center text-gray-500">
        <p>&copy; {currentYear} ChAImeleon. All rights reserved. Powered by Gemini.</p>
      </div>
    </footer>
  );
};

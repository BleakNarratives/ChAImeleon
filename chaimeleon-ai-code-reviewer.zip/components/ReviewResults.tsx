
import React from 'react';
import { ReviewResult } from '../types';
import { ResultCard } from './ResultCard';
import { Spinner } from './Spinner';

interface ReviewResultsProps {
  reviewResult: ReviewResult | null;
  isLoading: boolean;
  error: string | null;
}

const WelcomeMessage: React.FC = () => (
    <div className="text-center p-8">
      <h3 className="text-2xl font-bold text-gray-300 mb-2">Welcome to ChAImeleon</h3>
      <p className="text-gray-400">Paste your code on the left and click "Analyze Code" to get an AI-powered review.</p>
    </div>
);


export const ReviewResults: React.FC<ReviewResultsProps> = ({ reviewResult, isLoading, error }) => {
  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center h-full">
            <Spinner large={true} />
            <p className="mt-4 text-lg text-gray-400 animate-pulse">Analyzing your code...</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="flex items-center justify-center h-full p-4">
            <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-md" role="alert">
                <strong className="font-bold">Error: </strong>
                <span className="block sm:inline">{error}</span>
            </div>
        </div>
      );
    }

    if (!reviewResult) {
      return <WelcomeMessage />;
    }

    return (
      <div className="p-1">
        <div className="mb-6 p-4 bg-gray-900/50 rounded-lg border border-gray-700">
            <h3 className="text-xl font-semibold text-green-400 mb-2">Overall Assessment</h3>
            <p className="text-gray-300">{reviewResult.overallAssessment}</p>
        </div>
        <div className="space-y-4">
            {reviewResult.issues.map((issue) => (
                <ResultCard key={issue.id} issue={issue} />
            ))}
        </div>
      </div>
    );
  };

  return (
    <div className="bg-gray-800 rounded-lg shadow-xl h-full border border-gray-700 flex flex-col">
        <div className="p-3 border-b border-gray-700">
            <h2 className="text-lg font-semibold text-gray-200">Analysis Report</h2>
        </div>
        <div className="flex-grow overflow-y-auto p-4 custom-scrollbar">
            {renderContent()}
        </div>
    </div>
  );
};

